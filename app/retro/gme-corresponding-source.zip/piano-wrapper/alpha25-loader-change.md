# Piano Studio alpha.25 browser module correction
The original Node+Worker ES6 wrapper unconditionally imported `createRequire` from
`module`. Browsers cannot resolve this Node built-in. Only the JS loader is changed
to conditionally import `node:module` under Node. GME WebAssembly bytes are unchanged.
The original library, compiled wrapper C++, complete build script and license remain.
The revised readable loader is included as gme-engine-alpha25.mjs.
